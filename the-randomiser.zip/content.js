// ===== The Randomiser 🍉🎲 — content.js =====

const WEBSITES = [
  "https://youtube.com/@melonkingproductionsextras",
  "https://www.youtube.com",
  "https://www.google.com",
  "https://maps.google.com",
  "https://earth.google.com",
  "https://www.tiktok.com",
  "https://www.snapchat.com",
  "https://discord.com",
  "https://gemini.google.com",
  "https://chatgpt.com",
  "https://grok.com",
  "https://www.archive.org",
  "https://www.openstreetmap.org",
  "https://www.nasa.gov",
  "https://www.coolmathgames.com",
  "https://neal.fun",
  "https://www.geoguessr.com",
  "https://www.wikipedia.org",
  "https://www.roblox.com",
  "https://www.minecraft.net",
  "https://store.steampowered.com",
  "https://poki.com",
  "https://krunker.io",
  "https://agar.io",
  "https://diep.io",
  "https://slither.io",
  "https://humanbenchmark.com",
  "https://www.khanacademy.org",
  "https://www.codecademy.com",
  "https://www.freecodecamp.org",
  "https://developer.mozilla.org",
  "https://www.w3schools.com",
  "https://stackoverflow.com",
  "https://github.com",
  "https://replit.com",
  "https://www.photopea.com",
  "https://pixlr.com",
  "https://www.figma.com",
  "https://quickdraw.withgoogle.com",
  "https://pointerpointer.com",
  "https://longdogechallenge.com",
  "https://zoomquilt.org",
  "https://www.window-swap.com",
  "https://www.rainymood.com",
  "https://hackertyper.net",
  "https://thispersondoesnotexist.com",
  "https://www.random.org",
  "https://www.sporcle.com",
  "https://www.nytimes.com/games/wordle",
  "https://lichess.org",
  "https://www.chess.com",
  "https://www.duolingo.com",
  "https://www.reddit.com",
  "https://news.ycombinator.com",
  "https://www.twitch.tv",
  "https://open.spotify.com",
  "https://www.soundcloud.com",
  "https://www.deviantart.com",
  "https://www.behance.net",
  "https://codepen.io",
  "https://jsfiddle.net"
];

// ===== Avoid repeating the last visited site =====
let lastIndex = -1;

function getRandomIndex() {
  if (WEBSITES.length <= 1) return 0;
  let idx;
  do {
    idx = Math.floor(Math.random() * WEBSITES.length);
  } while (idx === lastIndex);
  return idx;
}

// ===== Toast helper =====
function showToast(message) {
  let toast = document.getElementById("randomiser-toast");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "randomiser-toast";
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toast._hideTimer);
  toast._hideTimer = setTimeout(() => toast.classList.remove("show"), 2200);
}

// ===== Button creation =====
(function init() {
  if (document.getElementById("randomiser-btn")) return; // guard against re-injection

  const btn = document.createElement("button");
  btn.id = "randomiser-btn";
  btn.innerHTML = '<span class="btn-dice">🎲</span> Random Website';
  btn.title = `${WEBSITES.length} destinations loaded — feeling lucky?`;
  document.body.appendChild(btn);

  // ===== Click handler =====
  btn.addEventListener("click", () => {
    // Spin animation
    btn.classList.add("spinning");
    btn.disabled = true;
    setTimeout(() => btn.classList.remove("spinning"), 500);

    const idx = getRandomIndex();
    lastIndex = idx;
    const site = WEBSITES[idx];

    // Show toast before navigating
    const domain = new URL(site).hostname.replace(/^www\./, "");
    showToast(`🚀 Launching ${domain}…`);

    setTimeout(() => {
      window.location.href = site;
    }, 600);
  });
})();
